<?php
error_reporting(0); // Turn off all error reporting
session_start();
$con=mysqli_connect('localhost','root','','db_college')
?>